# -*- coding: utf-8 -*-
"""
Created on Wed Sep 26 09:45:01 2018

@author: Youssef
"""

import matplotlib.pyplot as plt

RunNo = "Run3"
DSName = "CIFAR10"
FWs = ["Keras","Pytorch","Tensorflow"]


def PlotCPU(fileName,shape="r-"):
    file = open(fileName ,"r") 
    allLines = file.readlines()
    yAxis = []
    for line in allLines:    
        yAxis.append(float(line.split(',')[2].split(":")[1].replace("\n","")))
    plt.plot(yAxis,shape)
    plt.xlabel("Job Time (sec)")
    plt.ylabel('CPU Usage %')
    plt.savefig(RunNo+"-CPU-"+FWName+"-"+DSName)
    plt.show()

    
def PlotMemory(fileName,shape="g-"):
    file = open(fileName ,"r") 
    allLines = file.readlines()
    yAxis = []
    for line in allLines:    
        yAxis.append(float(line.split(' ')[1]))
    plt.plot(yAxis,shape)
    plt.xlabel("Job Time (sec)")
    plt.ylabel('Memory Usage (MB)')
    plt.savefig(RunNo+"-Memory-"+FWName+"-"+DSName)
    plt.show()    


def PlotCPU_Memory(filenameCPU,filenameMemory):
    PlotCPU(filenameCPU)
    #PlotMemoryNesma(filenameCPU)
    PlotMemory(filenameMemory)
    
if __name__ == '__main__':
#    cpuPath = "C:/Users/Youssef/Desktop/Results-GPU/MNIST/Keras/Run1/Cpu/"
#    memoryPath = "C:/Users/Youssef/Desktop/Results-GPU/MNIST/Keras/Run1/Memory/"
#    fileNameCpu = "Keras_MNIST_1539084057.txt"
#    fileNameMemory = "Keras_MNIST_1539084057.txt"
#    cpuPath +=fileNameCpu
#    memoryPath +=fileNameMemory
    for FWName in FWs : 
        PlotCPU_Memory("/home/nesma/Desktop/Results/"+DSName+"/"+FWName+"/"+RunNo+"/Cpu/cpu.txt","/home/nesma/Desktop/Results/"+DSName+"/"+FWName+"/"+RunNo+"/Memory/memory.txt")